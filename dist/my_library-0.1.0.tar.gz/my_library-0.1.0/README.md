# My Library

**My Library**, NLP ve Qdrant ile ilgili işlemleri kolaylaştıran, modüler bir Python kütüphanesidir.

## Kurulum

1. Bu projeyi klonlayın:
   ```bash
   git clone https://github.com/aysakkayaa/my_library.git
   cd my_library
   
  ```bash
  pip install .

